package com.example.sport;

public class Sport {
    private String name;
    private String description;
    private int imageId;

    private Sport(String name, String description,int imageId){
        this.name=name;
        this.description=description;
        this.imageId=imageId;

    }

    public static final Sport [] sports = {
            new Sport("Футбол","Спортивная игра двух команд, состоящая в том, что игроки стараются ударами ноги загнать мяч в ворота противникаю",R.drawable.football_icon),
            new Sport("Волейбол","Спортивная игра в мяч, перебрасываемой руками через сетку от одной команды к другой.",R.drawable.play_volleyball_icon),
            new Sport("Теннис","Спортивная игра маленьким мячом",R.drawable.tennis_icon),
            new Sport("Каратэ","Спортивная японская борьба",R.drawable.karate_icon),
            new Sport("Хоккей","Командная игра на льду на коньках в небольшой мяч или шайбу,ударяемые клюшкой.",R.drawable.hockey_ice_olympic_icon),
            new Sport("Плавание","Вид спорта или спортивная дисциплина, заключающаяся в преодолении вплавь за наименьшее время различных дистанций.",R.drawable.swimming_icon),
            new Sport("Бокс","Кулачный бой в специальных перчатках по определенным правилам между двумя спортсменами",R.drawable.athletic_boxing_exercise_game_sport_icon),
    };

    public String getName(){
        return name;
    };

    public String getDescription(){
        return description;
    };

    public int getImageId(){
        return imageId;
    };

    @Override
    public String toString(){
        return this.name;
    }
}
